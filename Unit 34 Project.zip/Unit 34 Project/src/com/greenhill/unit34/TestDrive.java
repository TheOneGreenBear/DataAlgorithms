package com.greenhill.unit34;

public class TestDrive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Generator.NumGen(10);

	}

}
