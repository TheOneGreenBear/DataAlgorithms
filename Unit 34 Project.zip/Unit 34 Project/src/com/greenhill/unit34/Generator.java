package com.greenhill.unit34;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class Generator {
	
	
	public static void NumGen(Integer numOfSets) {

		if (numOfSets <= 0) 
		{
			System.out.print("Please enter a number greater than 0!");
			return;
		}
		
		for(int i=0; i < numOfSets; i++) {
			
		//Create a HashSet called "Sets"
		Set<Integer> Sets = new HashSet<>();
		
		//Create a Random called "rnd"
		Random rnd = new Random();

		//While sets size is less than 6 add a new number using a
		//random number generator between 1-20
		while(Sets.size() < 6) {
			Sets.add(rnd.nextInt(19)+1);
		}
		//Convert the HashSet to a TreeSet so it's in an ascending order
		TreeSet<Integer> ts = new TreeSet<Integer> (Sets);
		
		System.out.println("Set: " + (i+1));
		
		System.out.println(ts.toString() + "\n");
			}
		}
	}	

